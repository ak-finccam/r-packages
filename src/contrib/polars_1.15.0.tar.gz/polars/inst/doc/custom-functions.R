## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
purrr_parallel_available <- rlang::is_installed(
  c("purrr", "carrier", "mirai"),
  version = c("1.1.0", "0.2.0", "2.4.0")
)

## ----setup--------------------------------------------------------------------
library(polars)

## -----------------------------------------------------------------------------
pl_standardize <- function(x) {
  (x - x$mean()) / x$std()
}

## -----------------------------------------------------------------------------
dat <- as_polars_df(mtcars[, c("carb", "mpg", "drat")])
dat$with_columns(
  carb_stand = pl_standardize(pl$col("carb"))
)

## -----------------------------------------------------------------------------
dat$map_columns(c("carb", "mpg"), \(col) scale(col$to_r_vector())[, 1])

## -----------------------------------------------------------------------------
library(purrr)

## -----------------------------------------------------------------------------
dat |>
  as.data.frame() |>
  map(\(col) scale(col)[, 1]) |>
  as_polars_df()

## ----eval=purrr_parallel_available--------------------------------------------
# Normally, polars registers serialization hooks for mirai via register_serial()
# in .onLoad (see R/integration-mirai.R), and users only need to call daemons(n).
# However, register_serial() does not reliably propagate the config to daemons
# in certain environments (observed in CI with mirai 2.6.0 / nanonext 1.8.0).
# As a workaround, we pass serial_config() directly to daemons() here.
# This should be revisited once the upstream issue is resolved.
polars_serial <- mirai::serial_config(
  class = c("polars_data_frame", "polars_lazy_frame", "polars_series"),
  sfunc = list(\(x) x$serialize(), \(x) x$serialize(), \(x) x$serialize()),
  ufunc = list(
    \(x) polars::pl$deserialize_df(x),
    \(x) polars::pl$deserialize_lf(x),
    \(x) polars::pl$deserialize_series(x)
  )
)
mirai::daemons(3, serial = polars_serial)

# Ensure the package is loaded on each daemon so that polars S3 methods
# (e.g. arithmetic operators for Series) are available.
mirai::everywhere({
  if (rlang::is_installed("polars")) {
    library(polars)
  } else {
    pkgload::load_all()
  }
})

## ----eval=purrr_parallel_available--------------------------------------------
dat |>
  as.data.frame() |>
  map(in_parallel(\(col) scale(col)[, 1])) |>
  as_polars_df()

## ----eval=purrr_parallel_available--------------------------------------------
dat |>
  as.list() |> # Convert to a list of Series, not converting each column to R vector yet.
  map_at(
    c("carb", "mpg"),
    # Since the Series are sent to each daemon,
    # we need to convert them to R vectors first by `$to_r_vector()`.
    # Finally, we convert them back to Series by `as_polars_series()` (in this case, optional).
    in_parallel(\(s) scale(s$to_r_vector())[, 1] |> polars::as_polars_series())
  ) |>
  as_polars_df()

## ----eval=purrr_parallel_available--------------------------------------------
mirai::daemons(0)

