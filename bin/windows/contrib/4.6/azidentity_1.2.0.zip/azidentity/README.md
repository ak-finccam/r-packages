# azidentity

`azidentity` acquires Microsoft Azure OAuth 2.0 access tokens from R using
the Azure SDK for Rust.

## Installation

Using rpx:

```sh
rpx add azidentity
```

Using base R:

```r
install.packages("azidentity")
```

## GitHub releases

Pushing a tag matching the version in `DESCRIPTION` (for example, `v1.2.0`)
builds a source package and binaries for the current and previous R release
series (`release` and `oldrel-1`):

- Ubuntu 24.04, x86_64
- Windows, x86_64
- macOS, arm64 (Apple Silicon)

The [GitHub Release](https://github.com/finccam/azure-identity-r/releases)
includes a download table and `SHA256SUMS`. The source archive is named
`azidentity_<version>.tar.gz`. Binary containers are named by the matrix, for
example `binary-windows-x86_64-release.zip`. Each contains the standard R
package archive: `azidentity_<version>.zip` on Windows, `.tgz` on macOS, or
`.tar.gz` on Ubuntu. Choose a container matching your R release series and
platform, then extract the outer ZIP. Ubuntu binaries are built for Ubuntu
24.04.

Install a downloaded archive from a terminal with:

```sh
R CMD INSTALL <downloaded-package-archive>
```

The workflow builds the source archive once and compiles every binary from it.
It does not run a test suite or `R CMD check`.

## Usage

```r
library(azidentity)

token <- default_azure_credential(
  "https://management.azure.com/.default"
)
```

Treat the returned bearer token as a secret. Do not print it, log it, or
store it in source control.

## Credential Chain

The package attempts credentials in this order:

1. Environment credential
2. Workload identity credential
3. Managed identity credential
4. Azure CLI credential
5. Azure Developer CLI credential

Environment authentication uses `AZURE_TENANT_ID`, `AZURE_CLIENT_ID`, and
`AZURE_CLIENT_SECRET`. For managed identity, a non-empty `AZURE_CLIENT_ID`
selects a user-assigned identity; otherwise, the system-assigned identity is
used.

For VM managed-identity discovery, the chain probes the IMDS token endpoint
once per attempt, with no retries and a one-second deadline. If the endpoint
does not respond, the chain continues to developer credentials. Once it
responds, the SDK's normal managed-identity authentication retries apply and
subsequent requests skip discovery. Configured managed-identity sources such
as App Service bypass this probe. A slow IMDS endpoint can miss the discovery
deadline even on an Azure VM.

The first successful credential is reused for the lifetime of the R process.
Tokens are cached by scope and refreshed when fewer than five minutes remain
before expiration.

### Selecting credentials

`AZURE_TOKEN_CREDENTIALS` limits the chain to some of its credentials, as in
the Azure SDK for Python:

| Value | Credentials |
|---|---|
| `dev` | Azure CLI, Azure Developer CLI |
| `prod` | Environment, workload identity, managed identity |
| A credential name, such as `AzureCliCredential` | Only that credential |

The value is case-insensitive. Any other value is an error. The package reads
the variable on the first call of `default_azure_credential()`.

Use `dev` on an Azure VM whose managed identity has no access to the resource.
The chain then skips the managed identity and uses the Azure CLI login.

## Requirements

Installing from source requires Cargo, Rust 1.88 or newer, and `xz`.

This is an independent project that uses the Microsoft Azure SDK for Rust. It
is not affiliated with or endorsed by Microsoft.
